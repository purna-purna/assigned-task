package com.example.myapplication;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiService {
    @POST("check_file_size.php")
    Call<ResponseBody> checkFileSize(@Body RequestBody requestBody);

    @POST("upload_chunk_file.php")
    Call<ResponseBody> uploadChunk(@Body RequestBody requestBody);
}
