package com.example.myapplication;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.util.Base64;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private Button uploadButton;
    private final String authenticationToken = "94cdffda0d6376c73f5d83c263f05653";
    private final String userName = "viraj_pawar";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        uploadButton = findViewById(R.id.uploadButton);
        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkFileSize("file.mp4", "video"); // Change this to your file path
            }
        });
    }

    private void checkFileSize(String fileName, String fileType) {
        String url = "https://sanpri.co.in/HRMSDEV/hrms_webservices/check_file_size.php";
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        Map<String, String> params = new HashMap<>();
        params.put("file_name", fileName);
        params.put("file_type", fileType);
        params.put("authentication_token", authenticationToken);
        params.put("user_name", userName);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        if (response.optInt("success") == 1) {
                            long size = response.optJSONArray("data").optJSONObject(0).optLong("size");
                            uploadFileInChunks("/path/to/your/file.mp4",0); // Change this to your file path
                        } else {
                            // Handle failure
                        }
                    }
                },
                error -> {
                    // Handle error
                }) {
            @Override
            protected Map<String, String> getParams() {
                return params;
            }
        };
        requestQueue.add(jsonObjectRequest);
    }

    private void uploadFileInChunks(String filePath, int chunkSize) {
        File file = new File(filePath);
        long totalSize = file.length();
        int chunks = (int) (totalSize / chunkSize) + (totalSize % chunkSize > 0 ? 1 : 0);

        for (int i = 0; i < chunks; i++) {
            byte[] buffer = new byte[chunkSize];
            try (FileInputStream fis = new FileInputStream(file)) {
                fis.skip(i * chunkSize);
                int bytesRead = fis.read(buffer);

                String encodedChunk = Base64.encodeToString(buffer, 0, bytesRead, Base64.NO_WRAP);

                String uploadUrl = "https://sanpri.co.in/HRMSDEV/hrms_webservices/upload_chunk_file.php";
                RequestQueue requestQueue = Volley.newRequestQueue(this);

                Map<String, String> params = new HashMap<>();
                params.put("file_name", file.getName());
                params.put("file_type", file.getName().endsWith(".mp4") ? "video" : "image");
                params.put("file_chunk", encodedChunk);
                params.put("authentication_token", authenticationToken);
                params.put("user_name", userName);

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, uploadUrl, null,
                        response -> {
                            if (response.optInt("success") == 1) {
                                // Chunk uploaded successfully
                            } else {
                                // Handle failure
                            }
                        },
                        error -> {
                            // Handle error
                        }) {
                    @Override
                    protected Map<String, String> getParams() {
                        return params;
                    }
                };
                requestQueue.add(jsonObjectRequest);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
