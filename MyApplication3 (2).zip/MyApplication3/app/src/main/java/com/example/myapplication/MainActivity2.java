package com.example.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileInputStream;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity2 extends AppCompatActivity {
    private Button selectFileButton;
    private Button uploadButton;
    private Uri selectedFileUri;
    private final String authToken = "94cdffda0d6376c73f5d83c263f05653";
    private final String userName = "viraj_pawar";
    private static final String BASE_URL = "https://your.server/HRMSDEV/hrms_webservices/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
       try {
           setContentView(R.layout.activity_main2);
           uploadButton = findViewById(R.id.uploadButton);
           selectFileButton = findViewById(R.id.selectFileButton);

           selectFileButton.setOnClickListener(v -> openFilePicker());
           uploadButton.setOnClickListener(v -> {
               if (selectedFileUri != null) {
                   checkFileSize(selectedFileUri);
               }
           });
       } catch (Exception e) {
           throw new RuntimeException(e);
       }

    }

    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            selectedFileUri = data.getData();
            uploadButton.setEnabled(true);
        }
    }

    private void checkFileSize(Uri fileUri) {
        String fileName = fileUri.getLastPathSegment().substring(fileUri.getLastPathSegment().lastIndexOf('/') + 1);
        String fileType = fileName.endsWith(".mp4") ? "video" : "image";

        // Prepare request body
        String requestBodyString = "{"
                + "\"file_name\": \"" + fileName + "\","
                + "\"file_type\": \"" + fileType + "\","
                + "\"authentication_token\": \"" + authToken + "\","
                + "\"user_name\": \"" + userName + "\""
                + "}";
        RequestBody requestBody = RequestBody.create(requestBodyString, MediaType.parse("application/json"));

        ApiService apiService = RetrofitClient.getClient(BASE_URL).create(ApiService.class);
        Call<ResponseBody> call = apiService.checkFileSize(requestBody);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful() && response.body() != null) {
                    long size = response.body().getData().get(0).getSize();
                    uploadFileInChunks(fileUri, size);
                } else {
                    Toast.makeText(MainActivity2.this, "File not found on server", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Toast.makeText(MainActivity2.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void uploadFileInChunks(Uri fileUri, long totalSize) {
        File file = new File(fileUri.getPath());
        int chunkSize = 1024 * 1024; // 1MB
        int chunks = (int) (totalSize / chunkSize) + (totalSize % chunkSize > 0 ? 1 : 0);

        for (int i = 0; i < chunks; i++) {
            final int chunkIndex = i; // Make `i` effectively final
            byte[] buffer = new byte[chunkSize];

            try (FileInputStream fis = new FileInputStream(file)) {
                fis.skip(chunkIndex * chunkSize);
                int bytesRead = fis.read(buffer);
                String encodedChunk = Base64.encodeToString(buffer, 0, bytesRead, Base64.NO_WRAP);

                // Prepare the chunk upload request body
                String chunkRequestBodyString = "{"
                        + "\"file_name\": \"" + file.getName() + "\","
                        + "\"file_type\": \"" + (file.getName().endsWith(".mp4") ? "video" : "image") + "\","
                        + "\"file_chunk\": \"" + encodedChunk + "\","
                        + "\"authentication_token\": \"" + authToken + "\","
                        + "\"user_name\": \"" + userName + "\""
                        + "}";
                RequestBody chunkRequestBody = RequestBody.create(chunkRequestBodyString, MediaType.parse("application/json"));

                // Upload the chunk
                ApiService apiService = RetrofitClient.getClient(BASE_URL).create(ApiService.class);
                Call<ResponseBody> chunkCall = apiService.uploadChunk(chunkRequestBody);
                chunkCall.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            // Handle successful chunk upload
                            // You may want to log or show a message for each chunk
                        } else {
                            Toast.makeText(MainActivity2.this, "Upload failed for chunk " + chunkIndex, Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Toast.makeText(MainActivity2.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        Toast.makeText(this, "Upload completed", Toast.LENGTH_SHORT).show();
    }
}